from fastapi import FastAPI

app = FastAPI()
app.title ="Fastapi SENA" 
app.version= "2.0.0"

@app.get('/', tags=['home'])
def home ():
    return "hello fastapi"

@app.post('/', tags=['Musica'])
def Musica ():
    return "the nigth wet me"

@app.put('/', tags=['Comida'])
def Comida ():
    return "Ensalada de frutas"

@app.delete('/', tags=['Deporte'])
def Deporte ():
    return "Futbol"



